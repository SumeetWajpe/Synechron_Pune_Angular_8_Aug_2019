import{Component, Input} from '@angular/core';// node_modules
import { Product } from './product.model';

@Component({
    selector:'product',
    template:`<h2>{{productdetails.title    }}</h2>
   

    <img [src]="productdetails.ImageUrl" 
   
    height="200px" width="200px" /><br />
      
            <b>Price : </b>{{productdetails.price  }} <br/>

   

    <b>Rating : </b>{{productdetails.rating  }} <br />
    <b>Quantity : </b>{{productdetails.quantity   }} <br />
   
    <button >
       {{productdetails.likes}} 
    </button>


    
    `
})
export class ProductComponent{
  @Input()  productdetails:Product={};
}
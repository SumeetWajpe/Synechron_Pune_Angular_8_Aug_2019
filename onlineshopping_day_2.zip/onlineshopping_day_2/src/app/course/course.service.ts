export class CourseService{
    courses:string[] = ['React','Angular','Typescript'];

    AddNewCourse(name:string){
        this.courses.push(name);
    }
}
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
import {RouterModule,Routes} from '@angular/router';
import { AppComponent } from './app.component';
import {ProductComponent} from './product.component';
import { ShoppingCartComponent } from './shopping-cart/shopping-cart.component';
import { QuantityPipe } from './quantity.pipe';
import { CourseComponent } from './course/course.component';
import { CourseService } from './course/course.service';
import { PostsComponent } from './posts/posts.component';
import { NewProductComponent } from './new-product/new-product.component';
import { PostDetailsComponent } from './post-details/post-details.component';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AuthGuard } from './auth.guard';

// const routes:Routes = [
//   {path:'',component:ShoppingCartComponent},
//   {path:'posts',component:PostsComponent},
//   {path:'postdetails/:id',component:PostDetailsComponent},
//   {path:'courses',component:CourseComponent}
// ];


const routes:Routes = [
  {path:"",component:LoginComponent},
  {path:'dashboard',
  component:DashboardComponent,
  children:[
    {path:'',component:ShoppingCartComponent},
    {path:'posts',component:PostsComponent},
    {path:'postdetails/:id',component:PostDetailsComponent},
    {path:'courses',component:CourseComponent}
    // ,    {path:'**',redirectTo:'/'}
  ],
  canActivate:[AuthGuard]
  }
];

@NgModule({
  declarations: [
    AppComponent,
    ProductComponent,
     ShoppingCartComponent,
     QuantityPipe,
     CourseComponent,
     PostsComponent,
     NewProductComponent,
     PostDetailsComponent,
     LoginComponent,
     DashboardComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot(routes)
  ],
  providers:[CourseService],
  bootstrap: [AppComponent]
})
export class AppModule { }

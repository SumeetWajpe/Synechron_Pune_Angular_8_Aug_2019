import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  uname:string="";
  upassword:string="";
  constructor(private userServObj:UserService,
    private router:Router) { }

  ngOnInit() {
  }
  Login(){
    if(this.uname == "admin" && this.upassword == "admin"){
        this.userServObj.setUserLoggedIn();
        this.router.navigate(['/dashboard'])
    }
  }

}

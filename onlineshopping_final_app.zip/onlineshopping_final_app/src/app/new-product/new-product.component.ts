import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import { Product } from '../product.model';

@Component({
  selector: 'app-new-product',
  templateUrl: './new-product.component.html',
  styleUrls: ['./new-product.component.css']
})
export class NewProductComponent implements OnInit {

  newProduct:Product= new Product();
  constructor(private prodServObj:ProductService) { }

  ngOnInit() {
  }
  AddProduct(theForm:any){
    if(theForm.valid){
      this.prodServObj.AddANewProduct(this.newProduct);
      this.newProduct = new Product();
    }
 
  }

}

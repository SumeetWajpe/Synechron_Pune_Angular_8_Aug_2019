import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { PostsService } from '../posts.service';
import { Post } from '../posts/post.model';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';
@Component({
  selector: 'app-post-details',
  templateUrl: './post-details.component.html',
  styleUrls: ['./post-details.component.css']
})
export class PostDetailsComponent implements OnInit {
thePostId:number;
currentPost:Post;
  constructor(private currRoute:ActivatedRoute,private postServObj:PostsService) { }

  ngOnInit() {
    this.currRoute.params.subscribe(
      p =>{
        this.thePostId = p.id;
        this.currentPost = this.postServObj.allPostsFromService.find(post=>post.id == p.id)
      } 
    );
  }

}

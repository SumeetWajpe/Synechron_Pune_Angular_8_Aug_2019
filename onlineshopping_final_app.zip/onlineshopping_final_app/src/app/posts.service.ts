import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Post } from './posts/post.model';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class PostsService {
  allPostsFromService:Post[]=[];
  constructor(private httpObj:HttpClient) { }

  getAllPosts():Observable<Post[]>{
    return this.httpObj.get<Post[]>('https://jsonplaceholder.typicode.com/posts');
  }
  // getAllPosts(){
  //   return this.httpObj.get('https://jsonplaceholder.typicode.com/posts').toPromise();
  // }
}

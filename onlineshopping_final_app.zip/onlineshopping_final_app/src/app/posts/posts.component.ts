import { Component, OnInit } from '@angular/core';
import { PostsService } from '../posts.service';
import { Post } from './post.model';

@Component({
  selector: 'app-posts',
  templateUrl: './posts.component.html',
  styleUrls: ['./posts.component.css']
})
export class PostsComponent implements OnInit {
  allPosts:Post[] = [];
  constructor(private servObj: PostsService) {
    // Using Observables
    var ObsPosts = this.servObj.getAllPosts();
    ObsPosts.subscribe( (response)=> {      
      this.allPosts  = response;
      this.servObj.allPostsFromService = response;
    },
    (err)=>{
      console.log(err)
    });
    // Using Promise

    // var aPromise = this.servObj.getAllPosts();
    // aPromise.then(
    //   (response)=>this.allPosts = response,
    //   (err)=>console.log(err)
    // );
  }

  ngOnInit() {
  }

}

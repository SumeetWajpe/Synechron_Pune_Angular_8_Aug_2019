import { PipeTransform, Pipe } from '@angular/core';

@Pipe({
    name:'qty'
})
export class QuantityPipe implements PipeTransform{
    transform(inputData:number,args:string){
        if(inputData == 0){
            return 'Out Of Stock !'
        }
            return inputData + " " + args;
    }
}
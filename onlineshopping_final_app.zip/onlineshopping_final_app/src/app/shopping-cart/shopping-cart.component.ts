import { Component, OnInit } from '@angular/core';
import { Product } from '../product.model';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-shopping-cart',
  templateUrl: './shopping-cart.component.html',
  styleUrls: ['./shopping-cart.component.css']
})
export class ShoppingCartComponent implements OnInit {
 heading:string="Online Shopping";
 productName:string="";
  products:Product[]=[];

    ChangeHeading(){
      this.heading = "Flipkart !";
    }
  constructor(private prodServObj:ProductService) { }

  ngOnInit() {
    this.products = this.prodServObj.getAllProducts();
  }

}
